package mx.edu.ittepic.seleccionar_numero;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView numero;
    Button botonNumero;
    CountDownTimer contador;
    double n=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Timer Push");

        numero = findViewById(R.id.n1);
        botonNumero = findViewById(R.id.n2);
        botonNumero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(botonNumero.getText().equals("START")){
                    iniciar();
                }else{
                    terminar();
                }
            }
        });
        contador = new CountDownTimer(300, 300) {
            @Override
            public void onTick(long l) {
            }

            @Override
            public void onFinish() {
                if (n>3.1){
                    n=0;
                }
                botonNumero.setText(String.format("%.1f",n));
                n = n+0.1;
                contador.start();
            }
        };

    }

    public void iniciar(){
        numero.setText(String.format("%.1f", (Math.random() * 2 + 1)));
        contador.start();
    }

    public void terminar(){
        contador.cancel();
        if (numero.getText().equals(botonNumero.getText())){
            Toast.makeText(this,"Very Well !!!",Toast.LENGTH_LONG).show();
            iniciar();
        }else{
            Toast.makeText(this,"Fail",Toast.LENGTH_LONG).show();
            iniciar();
        }
    }
}
